// Binary Search Tree - Demo in C++

#include<iostream>
using namespace std;

//Define Node for a BST.
struct BST_Node {
	int data;
	BST_Node* left;  // Pointing to Left Child.
	BST_Node* right; // Pointing to Right Child.
};

// Function to create a new Node
BST_Node* GetNewNode(int data) {
	BST_Node* newNode = new BST_Node();
	newNode->data = data;
	newNode->left = NULL;
	newNode->right = NULL;
	return newNode;
}

// To insert data in BST, returns address of root node
BST_Node* Insert(BST_Node* root, int data) {
	if(root == NULL) { // Empty tree
		root = GetNewNode(data);
	}
	// if data to be inserted is lesser, insert in left subtree.
	else if(data <= root->data) {
		root->left = Insert(root->left,data);
	}
	// else, insert in right subtree.
	else {
		root->right = Insert(root->right,data);
	}
	return root;
}

//To search an element in BST, returns true if element is found
bool Search(BST_Node* root,int data) {
	if(root == NULL) {
		return false;
	}
	else if(root->data == data) {
		return true;
	}
	else if(data <= root->data) {
		return Search(root->left,data);
	}
	else {
		return Search(root->right,data);
	}
}

// A utility function to do inorder traversal of BST
void Inorder(BST_Node* root) {
    if (root != NULL)
    {
        Inorder(root->left);
        cout << root->data <<" ";
        Inorder(root->right);
    }
}

int main() {
	BST_Node* root = NULL;  //An empty tree

	//Insert numbers
	root = Insert(root,14);
	root = Insert(root,9);
	root = Insert(root,18);
	root = Insert(root,11);
	root = Insert(root,15);
	root = Insert(root,20);
	root = Insert(root,5);

	// Ask for a number.
	int number;
	cout<<"Enter a number to search\n";
	cin>>number;

	//If found, print "Found", else "Not Found"
	if(Search(root,number) == true) cout<<"Found " << number << " in BST\n";
	else cout<<"Not Found " << number << " in BST\n";

    cout << "Inorder traversal of the BST \n";
    Inorder(root);

    //root = Insert(root,12);
    //cout << "\nInorder traversal of the BST after inserting 12\n";
    //Inorder(root);
}
